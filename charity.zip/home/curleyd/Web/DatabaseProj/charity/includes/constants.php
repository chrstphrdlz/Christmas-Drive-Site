<?php

//define constants here
define('DB_SERVER', 'localhost');
define('DB_USER', 'clint_c');
define('DB_PASSWORD', 'password');
define('DB_NAME', 'membership');
define('ADMIN_KEY', 'ad80857$C');
define('VOL_KEY', 'vol2357V');

?>